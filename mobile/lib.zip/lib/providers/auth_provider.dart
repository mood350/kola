import 'package:flutter/foundation.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';

enum AuthStatus { initial, loading, authenticated, unauthenticated, error }

/// Provider gérant l'état d'authentification de l'utilisateur.
/// Utilisé via `Provider.of<AuthProvider>(context)` ou `context.watch<AuthProvider>()`.
///
/// ⚠️ Important : le backend Kola exige une confirmation par email après
/// l'inscription (POST /auth/register renvoie 202 sans tokens). L'utilisateur
/// ne peut se connecter qu'après avoir cliqué sur le lien reçu par email.
class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  final StorageService _storageService = StorageService();

  AuthStatus _status = AuthStatus.initial;
  String? _errorMessage;
  String? _accessToken;

  AuthStatus get status => _status;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _status == AuthStatus.authenticated;

  /// Vérifie si un token existe déjà au démarrage de l'app (auto-login).
  Future<void> checkAuthStatus() async {
    final token = await _storageService.getToken();
    if (token != null && token.isNotEmpty) {
      _accessToken = token;
      _status = AuthStatus.authenticated;
    } else {
      _status = AuthStatus.unauthenticated;
    }
    notifyListeners();
  }

  /// Connexion par email + mot de passe (PAS de téléphone — le backend
  /// n'accepte que l'email pour le login, cf. AuthenticationRequest).
  Future<bool> login(String email, String password) async {
    _status = AuthStatus.loading;
    _errorMessage = null;
    notifyListeners();

    final result = await _authService.login(email: email, password: password);

    if (result.success) {
      _accessToken = result.accessToken;
      await _storageService.saveToken(result.accessToken!);
      if (result.refreshToken != null) {
        await _storageService.saveRefreshToken(result.refreshToken!);
      }
      _status = AuthStatus.authenticated;
      notifyListeners();
      return true;
    } else {
      _errorMessage = result.errorMessage;
      _status = AuthStatus.error;
      notifyListeners();
      return false;
    }
  }

  /// Inscription. Ne connecte PAS automatiquement l'utilisateur :
  /// le backend envoie un email de confirmation à valider avant le premier login.
  /// Retourne true si la demande a été acceptée (202), pas si le compte est actif.
  Future<bool> register({
    required String firstname,
    required String lastname,
    required String email,
    required String phoneNumber,
    required String countryCode,
    required String password,
  }) async {
    _status = AuthStatus.loading;
    _errorMessage = null;
    notifyListeners();

    final result = await _authService.register(
      firstname: firstname,
      lastname: lastname,
      email: email,
      phoneNumber: phoneNumber,
      countryCode: countryCode,
      password: password,
    );

    if (result.success) {
      _status = AuthStatus.unauthenticated; // compte créé mais pas encore confirmé
      notifyListeners();
      return true;
    } else {
      _errorMessage = result.errorMessage;
      _status = AuthStatus.error;
      notifyListeners();
      return false;
    }
  }

  Future<bool> forgotPassword(String email) async {
    final result = await _authService.forgotPassword(email);
    if (!result.success) {
      _errorMessage = result.errorMessage;
      notifyListeners();
    }
    return result.success;
  }

  Future<void> logout() async {
    if (_accessToken != null) {
      await _authService.logout(_accessToken!);
    }
    await _storageService.clearAll();
    _accessToken = null;
    _status = AuthStatus.unauthenticated;
    notifyListeners();
  }
}