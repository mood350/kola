import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/constants/app_constants.dart';

/// Résultat générique pour les appels d'authentification qui renvoient des tokens.
class AuthTokenResult {
  final bool success;
  final String? accessToken;
  final String? refreshToken;
  final String? errorMessage;

  AuthTokenResult.ok({this.accessToken, this.refreshToken})
      : success = true,
        errorMessage = null;

  AuthTokenResult.fail(this.errorMessage)
      : success = false,
        accessToken = null,
        refreshToken = null;
}

/// Résultat générique pour les appels qui ne renvoient pas de body (register, etc.)
class AuthActionResult {
  final bool success;
  final String? errorMessage;

  AuthActionResult.ok() : success = true, errorMessage = null;
  AuthActionResult.fail(this.errorMessage) : success = false;
}

/// Service gérant les appels API liés à l'authentification.
/// Les noms de champs et la forme des requêtes/réponses correspondent
/// EXACTEMENT aux DTOs Spring Boot : AuthenticationRequest, RegistrationRequest,
/// AuthenticationResponse (cf. com.kola.backend.auth.*).
class AuthService {
  /// POST /api/auth/login
  /// Body attendu : { "email": "...", "password": "..." }
  /// Réponse : { "access_token": "...", "refresh_token": "..." }
  Future<AuthTokenResult> login({
    required String email,
    required String password,
  }) async {
    try {
      final response = await http
          .post(
        Uri.parse('${AppConstants.baseUrl}/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'email': email,
          'password': password,
        }),
      )
          .timeout(AppConstants.apiTimeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        return AuthTokenResult.ok(
          accessToken: data['access_token'] as String?,
          refreshToken: data['refresh_token'] as String?,
        );
      } else {
        return AuthTokenResult.fail(_extractErrorMessage(response.body) ?? 'Échec de connexion');
      }
    } catch (e) {
      return AuthTokenResult.fail('Erreur réseau : impossible de contacter le serveur');
    }
  }

  /// POST /api/auth/register
  /// Body attendu : { "firstname", "lastname", "email", "phoneNumber"
  ///                  (format international, ex: +22890000000),
  ///                  "countryCode" (ISO 3166-1 alpha-2, ex: "TG"), "password"
  ///                  (8+ caractères, 1 maj, 1 min, 1 chiffre) }
  /// Réponse : 202 Accepted, PAS de body. Un email de confirmation est envoyé ;
  /// l'utilisateur doit confirmer son compte avant de pouvoir se connecter.
  Future<AuthActionResult> register({
    required String firstname,
    required String lastname,
    required String email,
    required String phoneNumber,
    required String countryCode,
    required String password,
  }) async {
    try {
      final response = await http
          .post(
        Uri.parse('${AppConstants.baseUrl}/auth/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'firstname': firstname,
          'lastname': lastname,
          'email': email,
          'phoneNumber': phoneNumber,
          'countryCode': countryCode,
          'password': password,
        }),
      )
          .timeout(AppConstants.apiTimeout);

      if (response.statusCode == 202) {
        return AuthActionResult.ok();
      } else {
        return AuthActionResult.fail(_extractErrorMessage(response.body) ?? "Échec de l'inscription");
      }
    } catch (e) {
      return AuthActionResult.fail('Erreur réseau : impossible de contacter le serveur');
    }
  }

  /// GET /api/auth/confirm?token=...
  Future<AuthActionResult> confirmAccount(String token) async {
    try {
      final response = await http
          .get(Uri.parse('${AppConstants.baseUrl}/auth/confirm?token=$token'))
          .timeout(AppConstants.apiTimeout);

      if (response.statusCode == 200) {
        return AuthActionResult.ok();
      }
      return AuthActionResult.fail(_extractErrorMessage(response.body) ?? 'Échec de la confirmation');
    } catch (e) {
      return AuthActionResult.fail('Erreur réseau : impossible de contacter le serveur');
    }
  }

  /// POST /api/auth/forgot-password?email=...
  /// ⚠️ Query param, PAS de body JSON.
  Future<AuthActionResult> forgotPassword(String email) async {
    try {
      final uri = Uri.parse('${AppConstants.baseUrl}/auth/forgot-password')
          .replace(queryParameters: {'email': email});
      final response = await http.post(uri).timeout(AppConstants.apiTimeout);

      if (response.statusCode == 202) {
        return AuthActionResult.ok();
      }
      return AuthActionResult.fail(_extractErrorMessage(response.body) ?? "Échec de l'envoi");
    } catch (e) {
      return AuthActionResult.fail('Erreur réseau : impossible de contacter le serveur');
    }
  }

  /// POST /api/auth/reset-password?token=...&newPassword=...
  /// ⚠️ Query params, PAS de body JSON.
  Future<AuthActionResult> resetPassword({
    required String token,
    required String newPassword,
  }) async {
    try {
      final uri = Uri.parse('${AppConstants.baseUrl}/auth/reset-password').replace(
        queryParameters: {'token': token, 'newPassword': newPassword},
      );
      final response = await http.post(uri).timeout(AppConstants.apiTimeout);

      if (response.statusCode == 200) {
        return AuthActionResult.ok();
      }
      return AuthActionResult.fail(_extractErrorMessage(response.body) ?? 'Échec de la réinitialisation');
    } catch (e) {
      return AuthActionResult.fail('Erreur réseau : impossible de contacter le serveur');
    }
  }

  /// POST /api/auth/refresh-token
  /// Header : Authorization: Bearer <refresh_token>
  Future<AuthTokenResult> refreshToken(String refreshToken) async {
    try {
      final response = await http
          .post(
        Uri.parse('${AppConstants.baseUrl}/auth/refresh-token'),
        headers: {'Authorization': 'Bearer $refreshToken'},
      )
          .timeout(AppConstants.apiTimeout);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        return AuthTokenResult.ok(
          accessToken: data['access_token'] as String?,
          refreshToken: data['refresh_token'] as String?,
        );
      }
      return AuthTokenResult.fail('Session expirée, veuillez vous reconnecter');
    } catch (e) {
      return AuthTokenResult.fail('Erreur réseau : impossible de contacter le serveur');
    }
  }

  /// POST /api/auth/logout
  /// Header : Authorization: Bearer <access_token>
  /// Réponse : 204 No Content
  Future<void> logout(String accessToken) async {
    try {
      await http.post(
        Uri.parse('${AppConstants.baseUrl}/auth/logout'),
        headers: {'Authorization': 'Bearer $accessToken'},
      ).timeout(AppConstants.apiTimeout);
    } catch (_) {
      // Si le logout réseau échoue, on supprime quand même les tokens locaux
      // (cf. AuthProvider.logout) — l'important est que le frontend déconnecte.
    }
  }

  /// Extrait un message d'erreur lisible depuis le body JSON d'erreur Spring Boot.
  /// Gère le format Spring "MethodArgumentNotValidException" (liste de field errors)
  /// ainsi qu'un format simple { "message": "..." }.
  String? _extractErrorMessage(String body) {
    try {
      final data = jsonDecode(body);
      if (data is Map<String, dynamic>) {
        if (data['message'] != null) return data['message'] as String;
        if (data['errors'] is List && (data['errors'] as List).isNotEmpty) {
          final firstError = (data['errors'] as List).first;
          if (firstError is Map && firstError['defaultMessage'] != null) {
            return firstError['defaultMessage'] as String;
          }
        }
      }
    } catch (_) {
      // body non-JSON ou vide : on retombe sur le message par défaut de l'appelant.
    }
    return null;
  }
}